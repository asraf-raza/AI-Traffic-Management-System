# AI Traffic Management System

A single-file Python/Flask application that combines YOLO vehicle detection,
traffic density calculation, emergency-vehicle detection, and adaptive
traffic-signal decision logic behind a browser dashboard — no terminal
interaction needed once it's running.

## What it does

| Requirement                     | Where it lives in `app.py`                          |
|----------------------------------|-------------------------------------------------------|
| Vehicle detection (YOLO)         | `VehicleDetector` — YOLOv8 via `ultralytics`, class filter for car/motorcycle/bus/truck |
| Traffic density calculation      | `DensityAnalyzer` — rolling per-lane vehicle counts bucketed into LOW / MEDIUM / HIGH |
| Emergency vehicle detection      | `EmergencyDetector` — HSV red/blue light-bar thresholding + flicker/strobe-rate check across frames |
| Traffic-signal decision logic    | `SignalController` — adaptive round-robin state machine (RED → GREEN → YELLOW → ALL_RED), green duration scales with density, emergency lanes pre-empt the cycle |
| Browser UI                       | `INDEX_HTML` (embedded in `app.py`) — drag-and-drop upload, live annotated MJPEG stream, live lane/signal dashboard, decision log |

The camera view is split into four quadrants (North/East/South/West) as a
single-camera approximation of a 4-way intersection — swap `lane_zones()`
for real per-approach camera feeds in a multi-camera deployment.

## Run it

```bash
pip install -r requirements.txt
python app.py
```

Then open **http://127.0.0.1:5000** and drag in a traffic video
(`.mp4`, `.avi`, `.mov`, `.mkv`, `.webm`). The annotated stream and the live
signal dashboard start immediately; the video loops continuously for demo
purposes.

## Detection backend

- If `ultralytics` is installed, the app uses **YOLOv8n** for real object
  detection (weights `yolov8n.pt` auto-download the first time you run it —
  needs an internet connection once).
- If `ultralytics` is not installed, the app **automatically falls back** to
  a pure-OpenCV background-subtraction blob detector, so the whole pipeline
  (density calc, emergency detection, signal logic, UI) still runs with zero
  extra setup. The active backend is shown in the top-right pill in the UI.

## Emergency vehicle detection heuristic

For every detected vehicle box, the crop is converted to HSV and thresholded
for red and blue hue ranges (siren light-bar colors). A lane is only flagged
as an emergency lane if that red/blue signal **flickers on and off** across
recent frames (a strobe), not just present in one frame — this avoids false
positives from vehicles that are simply painted red or blue.

## Signal decision logic

- Normal operation: lanes cycle North → East → South → West, each getting a
  GREEN phase whose duration is picked from `GREEN_TIME[density_level]`
  (12s / 22s / 35s for LOW / MEDIUM / HIGH), followed by a 3s YELLOW and a
  1s ALL-RED clearance interval.
- Emergency pre-emption: the moment a lane reports a confirmed emergency
  vehicle, that lane is forced to GREEN immediately (all others RED) and
  held for at least `EMERGENCY_HOLD_TIME` (18s) or until the emergency
  vehicle clears, whichever is longer — then the normal cycle resumes from
  the next lane.

## Tuning

All thresholds are constants at the top of `app.py`:
`DENSITY_THRESHOLDS`, `GREEN_TIME`, `YELLOW_TIME`, `EMERGENCY_HOLD_TIME`,
`EMERGENCY_COLOR_RATIO`, `EMERGENCY_MIN_TRANSITIONS`, `FRAME_TARGET_FPS`.

## Files

```
AI_Traffic_Management/
├── app.py            # everything: detection, density, emergency logic,
│                      # signal controller, Flask routes, embedded HTML/CSS/JS
├── requirements.txt
└── README.md
```
